//
//
// File generated from our OpenAPI spec
//
//

package stripe

const (
	apiVersion string = "2022-11-15"
)
